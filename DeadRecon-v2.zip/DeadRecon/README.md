# DEAD RECON — v2 source drop

Drop the `app/src/...` files into your existing project (package `com.deadrecon.app`).
Your `ui/theme/Dead_ReconTheme` is still used; the old single-file `MainActivity.kt` is replaced.

## File layout

```
MainActivity.kt            Android shell: sensors (100 Hz), CameraX, Compose wiring only
nav/NavigationEngine.kt    The whole fusion pipeline (pure Kotlin, unit-testable)
nav/OrientationEkf.kt      Quaternion EKF: gyro predict, gravity update, gated compass-yaw update
nav/PositionEkf.kt         6-state EKF [pE pN vE vN bE bN] (accel-bias states added)
nav/StepDetector.kt        Peak/valley step detector + Weinberg stride model
nav/ReturnNavigator.kt     Breadcrumb retrace guidance (turn left/right, distance)
nav/MatrixMath.kt          Small matrix lib, Joseph-form EKF update with chi² gating
ai/MotionClassifier.kt     HMM motion-mode recogniser (stationary/walk/run/crawl/handling)
vision/OpticalFlowEngine.kt Pyramidal Lucas-Kanade, forward-backward check, robust motion fit
geo/GeoCoordinates.kt      Separate geographic layer: WGS-84 local tangent plane, parsing, DMS
map/DemoMap.kt             Fictional demo floor plan + route for the demo walker
ui/DeadReconScreen.kt      Console UI (header, camera, map, coords, telemetry, controls)
ui/MapCanvas.kt            Map rendering: floor plan, explored cells, path, pointer, 2σ ellipse
test/.../NavigationCoreTest.kt  JVM tests (./gradlew test) — simulated walks, geo, optical flow
```

## Build requirements

Manifest (inside `<manifest>`; lock portrait because the vision maths assumes device axes = screen axes):

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera.any" android:required="false" />
<!-- on the <activity>: android:screenOrientation="portrait" -->
```

Dependencies you should already have: CameraX (`camera-core`, `camera-camera2`, `camera-lifecycle`,
`camera-view`), Compose BOM with Material3 (drawText / TextMeasurer needs Compose ≥ 1.4), `junit:junit` for tests.
No network, GPS or location permission is used.

## How to use

1. Start the app and hold the phone still ~3 s (status: ALIGNING → SET START POINT).
2. Type the start latitude/longitude (decimal `12.9716`, `77.59 E`, or DMS `12°58'17.8"N`), press **SET START POINT**.
3. Walk. Current lat/lon, N/E displacement, and the pointer on the map update live.
4. **RETURN TO START** switches to retrace guidance along your own recorded path.
5. **CALIBRATE STRIDE**: press, walk exactly 10 m, press DONE. Do this once per person — it is the biggest accuracy win.
6. **DEMO WALK** (after setting a start point) drives a synthetic walker through the demo map using the real
   step → EKF path. The white ring is ground truth, so you can see drift. Press RETURN TO START during the demo to see retrace.

## What the "AI" layer does now

- **Motion-mode HMM** — Gaussian emission models on accel energy, rotation energy and step cadence,
  smoothed with a forward filter. The mode picks the filter behaviour: ZUPT + gyro-bias learning when still,
  step updates when walking/running, vision-led velocity when crawling, damping when the phone is just being handled.
  Emission parameters are hand-set priors; fit them from logged sessions with `setEmission()`.
- **Self-supervised visual scale** — monocular flow has no metric scale, so the engine learns scene depth online from
  agreement with step velocity, and only fuses vision once direction consistency is proven (it cannot hurt the
  estimate before then). Rotation-induced flow is removed with the gyro; image expansion is used to see forward motion.
- **Adaptive trust** — accelerometer noise scales with dynamics, compass is down-weighted/rejected when the field
  magnitude or dip deviates from the start-up reference (rebar, machinery), vision noise scales with confidence,
  and every vision update passes a chi² innovation gate.

## Limits (honest)

- Position error grows with distance; the ± figure uses EKF covariance plus ~3 % of distance walked.
- The phone should be held in front of you (flat or upright, camera forward). Pocket carry is not supported yet.
- The demo map is fictional and not aligned to real geography.
- Magnetic declination defaults to 0° (`engine.declinationDeg`).
